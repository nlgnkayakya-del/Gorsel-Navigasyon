GÖRSEL NAVİGASYON MVP

1) index.html dosyasını ücretsiz bir HTTPS hosting hizmetine yükleyin.
2) iPhone'da çıkan site adresini Safari'de açın.
3) "Gerçek GPS'i Aç" düğmesine basın ve konum izni verin.
4) Evde test için "Demo İlerle" kullanılabilir.

ÖNEMLİ:
- İçerideki Alibeyköy–Eyüp–Haliç–Taksim koordinatları yalnızca prototip amaçlı yaklaşık değerlerdir.
- Saha testinden önce gerçek rota üzerinde kesin noktalar ölçülmeli ve gerçek sürüş açısındaki fotoğraflar eklenmelidir.
- Araç kullanırken sürücünün telefonu elle kullanmaması gerekir. İlk saha testinde ekranı yolcu takip etmelidir.
